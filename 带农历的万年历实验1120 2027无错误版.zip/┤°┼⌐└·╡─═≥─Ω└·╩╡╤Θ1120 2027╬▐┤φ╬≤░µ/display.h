#ifndef __DISPLAY_H__
#define __DISPLAY_H__
#include <reg52.h>
#include "ds1302.h"
#include "lunar.h"
#endif